from setuptools import setup

setup(
    name = "Mauricio Gasca",
    version = "1.0",
    description = "Paquete Distribuido",
    author = "Curso-Python",
    author_email = "mgasca12@gmail.com",
    packages = ["carpeta_modulos"]
)